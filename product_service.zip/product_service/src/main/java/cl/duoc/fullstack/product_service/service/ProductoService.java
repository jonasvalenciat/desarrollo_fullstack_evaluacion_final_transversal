package cl.duoc.fullstack.product_service.service;

import cl.duoc.fullstack.product_service.dto.ProductRequest;
import cl.duoc.fullstack.product_service.dto.ProductResponse;
import cl.duoc.fullstack.product_service.model.Categoria;
import cl.duoc.fullstack.product_service.model.ProductHistory;
import cl.duoc.fullstack.product_service.model.Producto;
import cl.duoc.fullstack.product_service.repository.CategoriaRepository;
import cl.duoc.fullstack.product_service.repository.ProductHistoryRepository;
import cl.duoc.fullstack.product_service.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ProductoService {

    private final ProductoRepository productoRepository;
    private final CategoriaRepository categoriaRepository;
    private final ProductHistoryRepository productHistoryRepository;

    public ProductoService(ProductoRepository productoRepository,
                           CategoriaRepository categoriaRepository,
                           ProductHistoryRepository productHistoryRepository) {
        this.productoRepository = productoRepository;
        this.categoriaRepository = categoriaRepository;
        this.productHistoryRepository = productHistoryRepository;
    }

    public List<ProductResponse> findAll() {
        return productoRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    public ProductResponse findById(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con id: " + id));
        return toResponse(producto);
    }

    public List<ProductResponse> findByCategoriaId(Long categoriaId) {
        return productoRepository.findByCategoriaId(categoriaId).stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public ProductResponse create(ProductRequest request, String motivo) {
        Categoria categoria = categoriaRepository.findById(request.categoriaId())
                .orElseThrow(() -> new RuntimeException("Categoria no encontrada con id: " + request.categoriaId()));

        Producto producto = Producto.builder()
                .nombre(request.nombre())
                .descripcion(request.descripcion())
                .precio(request.precio())
                .stock(request.stock())
                .categoria(categoria)
                .build();

        Producto saved = productoRepository.save(producto);

        recordChange(null, saved, motivo);

        return toResponse(saved);
    }

    @Transactional
    public ProductResponse update(Long id, ProductRequest request, String motivo) {
        Producto existing = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con id: " + id));

        Categoria categoria = categoriaRepository.findById(request.categoriaId())
                .orElseThrow(() -> new RuntimeException("Categoria no encontrada con id: " + request.categoriaId()));

        Double precioAnterior = existing.getPrecio();
        Integer stockAnterior = existing.getStock();

        existing.setNombre(request.nombre());
        existing.setDescripcion(request.descripcion());
        existing.setPrecio(request.precio());
        existing.setStock(request.stock());
        existing.setCategoria(categoria);

        Producto updated = productoRepository.save(existing);

        if (precioAnterior != null && updated.getPrecio() != null && !precioAnterior.equals(updated.getPrecio())) {
            recordChange(existing, updated, motivo);
        }

        return toResponse(updated);
    }

    @Transactional
    public void delete(Long id) {
        if (!productoRepository.existsById(id)) {
            throw new RuntimeException("Producto no encontrado con id: " + id);
        }
        productoRepository.deleteById(id);
    }

    public List<ProductHistory> getHistoryByProductoId(Long productoId) {
        return productHistoryRepository.findByProductoIdOrderByFechaCambioDesc(productoId);
    }

    private void recordChange(Producto before, Producto after, String motivo) {
        ProductHistory history = ProductHistory.builder()
                .productoId(after.getId())
                .precioAnterior(before != null ? before.getPrecio() : null)
                .precioNuevo(after.getPrecio())
                .stockAnterior(before != null ? before.getStock() : null)
                .stockNuevo(after.getStock())
                .fechaCambio(LocalDateTime.now())
                .motivo(motivo)
                .build();

        productHistoryRepository.save(history);
    }

    private ProductResponse toResponse(Producto producto) {
        return new ProductResponse(
                producto.getId(),
                producto.getNombre(),
                producto.getDescripcion(),
                producto.getPrecio(),
                producto.getStock(),
                producto.getCategoria().getNombre()
        );
    }
}
