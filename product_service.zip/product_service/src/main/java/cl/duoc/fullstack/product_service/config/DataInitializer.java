package cl.duoc.fullstack.product_service.config;

import cl.duoc.fullstack.product_service.model.Categoria;
import cl.duoc.fullstack.product_service.model.Producto;
import cl.duoc.fullstack.product_service.repository.CategoriaRepository;
import cl.duoc.fullstack.product_service.repository.ProductoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final CategoriaRepository categoriaRepository;
    private final ProductoRepository productoRepository;

    public DataInitializer(CategoriaRepository categoriaRepository,
                           ProductoRepository productoRepository) {
        this.categoriaRepository = categoriaRepository;
        this.productoRepository = productoRepository;
    }

    @Override
    public void run(String... args) {
        if (categoriaRepository.count() == 0) {
            Categoria juegos = categoriaRepository.save(Categoria.builder()
                    .nombre("Juegos")
                    .build());

            Categoria consolas = categoriaRepository.save(Categoria.builder()
                    .nombre("Consolas")
                    .build());

            productoRepository.save(Producto.builder()
                    .nombre("Zelda: Tears of the Kingdom")
                    .descripcion("Aventura epica en el reino de Hyrule")
                    .precio(59.99)
                    .stock(25)
                    .categoria(juegos)
                    .build());

            productoRepository.save(Producto.builder()
                    .nombre("Nintendo Switch OLED")
                    .descripcion("Consola hibrida con pantalla OLED de 7 pulgadas")
                    .precio(349.99)
                    .stock(15)
                    .categoria(consolas)
                    .build());

            System.out.println("=== Datos iniciales cargados exitosamente ===");
        }
    }
}
