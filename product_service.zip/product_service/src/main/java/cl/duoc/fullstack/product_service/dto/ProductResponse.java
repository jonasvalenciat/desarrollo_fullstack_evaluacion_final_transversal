package cl.duoc.fullstack.product_service.dto;

public record ProductResponse(
        Long id,
        String nombre,
        String descripcion,
        Double precio,
        Integer stock,
        String categoriaNombre
) {
}
