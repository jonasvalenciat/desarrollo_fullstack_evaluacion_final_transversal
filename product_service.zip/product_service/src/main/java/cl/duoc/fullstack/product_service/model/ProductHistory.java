package cl.duoc.fullstack.product_service.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "product_history")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long productoId;

    private Double precioAnterior;

    private Double precioNuevo;

    private Integer stockAnterior;

    private Integer stockNuevo;

    @Column(nullable = false)
    private LocalDateTime fechaCambio;

    private String motivo;
}
