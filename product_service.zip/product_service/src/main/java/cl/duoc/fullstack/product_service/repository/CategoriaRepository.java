package cl.duoc.fullstack.product_service.repository;

import cl.duoc.fullstack.product_service.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
}
