package cl.duoc.fullstack.product_service.repository;

import cl.duoc.fullstack.product_service.model.ProductHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductHistoryRepository extends JpaRepository<ProductHistory, Long> {

    List<ProductHistory> findByProductoIdOrderByFechaCambioDesc(Long productoId);
}
