package cl.duoc.fullstack.product_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

public record ProductRequest(
        @NotBlank(message = "El nombre es obligatorio")
        String nombre,

        String descripcion,

        @Positive(message = "El precio debe ser mayor a cero")
        Double precio,

        Integer stock,

        Long categoriaId
) {
}
